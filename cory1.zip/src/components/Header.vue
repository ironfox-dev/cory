<template>
  <div class="bg-header w-full">
    <div class="w-full h-full bg-black bg-cover bg-opacity-70">
      <div class="flex p-10 justify-between">
        <div>
          <img src="../assets/image-1.png" alt="">
        </div>
        <div class="flex">
          <div class="text-white mx-4">Home</div>
          <div class="text-white mx-4">Revenue</div>
          <div class="text-white mx-4">Membership</div>
          <div class="text-white mx-4">About us</div>
        </div>
        <div class="flex">
          <div>
            <img src="../assets/cart.png" class="mt-0.5" alt="">
          </div>
          <div class="text-white ml-4">Account</div>
        </div>
      </div>
      <div class="flex pl-10 pb-20">
        <div class="mt-8">
          <div class="text-white" style="writing-mode: tb">Follow us</div>
          <img src="../assets/instagram.png" class="w-4 mt-2 ml-0.5" alt="">
          <img src="../assets/twitter.png" class="w-4 my-2 ml-0.5" alt="">
        </div>
        <div class="w-full flex-column justify-center px-48">
          <div class="flex">
            <div class="w-12 mt-3 mr-3 ml-1 h-px bg-white"></div>
            <div class="text-white">REVR</div>
          </div>
          <div class="text-7xl text-white font-medium">
            Revenue Projection For Any US Vacation Property
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "Header",
  components: {
    
  },
  methods: {
   
  },
};
</script>
<style scoped>
.bg-header {
  background-image: url('../assets/bg-header.png');
}
</style>