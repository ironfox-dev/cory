import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import './index.css'

createApp(App).use(router).mount('#app')
