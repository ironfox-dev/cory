<template>
  <div class="">
    <Header />
  </div>
</template>

<script>
// @ is an alias to /src
import Header from "@/components/Header.vue";
export default {
  name: "Revenue",
  components: {
      Header,
  },
  methods: {
    
  },
};
</script>
<style>

</style>