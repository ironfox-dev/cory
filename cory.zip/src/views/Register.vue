<template>
  <div class="w-full h-full bg-cover bg-img bg-no-repeat flex justify-end">
    <div class="w-logo h-screen bg-gray-900 bg-opacity-90 overflow-y-auto">
      <div class="flex mt-14 justify-between">
        <div class="flex ml-3">
          <div class="mt-0.5">
            <img src="../assets/arrow_back_ios_24px.png" alt="">
          </div>
          <div class="text-gray-400 ml-1">Back</div>
          <img src="../assets/Artboard.png" alt="logo" class="ml-2 -mt-4 mr-4 mb-10"/>
        </div>
        
        <div class="mr-12">
          <div class="text-white ml-9 text-xs">STEP 01/03</div>
          <div class="text-white">Personal Info.</div>
        </div>
      </div>
      <div class="text-white text-3xl ml-24 font-bold">Register</div>
      <div class="ml-24 mr-12 mt-6">
        <div class="w-full h-px bg-white"></div>
        <div class="text-white mt-12">Your fullname*</div>
        <input type="text" placeholder="Enter your name" class="p-4 text-white border-white border mt-2 w-full rounded bg-transparent border-solid">
        <div class="text-white mt-6">Email address*</div>
        <input type="text" placeholder="Enter email address" class="p-4 text-white border-white border mt-2 w-full rounded bg-transparent border-solid">
        <div class="text-white mt-6">Create Password*</div>
        <div class="flex">
          <input type="text" placeholder="Create password" class="p-4 text-white w-4/5 border-white border mt-2 rounded bg-transparent border-solid rounded-r-none border-r-0">
          <button class="p-4 border-white border mt-2 w-1/5 rounded bg-transparent border-solid rounded-l-none border-l-0">Show</button>
        </div>
        <div class="flex justify-between mt-6">
          <div class="flex">
            <label class="main text-white">I agree to terms & conditions
                <input type="checkbox" checked="checked">
                <span class="geekmark mt-0.5"></span>
            </label>
          </div>
        </div>
        <button class="bg-custom rounded text-white w-full p-4 mt-10">Register Account</button>
        <div class="flex justify-between mt-10">
          <div class="w-2/5 h-px bg-white"></div>
          <div class="text-white -mt-3">Or</div>
          <div class="w-2/5 h-px bg-white"></div>
        </div>
        <button class="p-4 w-full bg-white rounded font-bold mt-6 mb-6">
          <div class="flex justify-between mx-4">
            <img src="../assets/flat-color-icons_google.png" alt="">
            <div>Register with Google</div>
            <img src="" alt="">
          </div>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Register",
  components: {
  },
  methods: {
    
  },
};
</script>
<style>
.bg-img {
  background-image: url('../assets/bg.png');
}
.w-logo {
  width: 593px;
}
::placeholder {
  opacity: 1;
}
.bg-custom {
  background: #91B539;
}
.color-custom {
  color: #91B539;
}
.main {
    display: block;
    position: relative;
    padding-left: 45px;
    margin-bottom: 10px;
    cursor: pointer;
}
  
/* Hide the default checkbox */
input[type=checkbox] {
    visibility: hidden;
}
  
.geekmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 20px;
    width: 20px;
    background-color: #91B539;
    border-radius: 5px;
}
  
.main input:checked ~ .geekmark {
    background-color: #91B539;
}
  
.geekmark:after {
    content: "";
    position: absolute;
    display: none;
}
  
.main input:checked ~ .geekmark:after {
    display: block;
}
  
.main .geekmark:after {
    left: 7px;
    bottom: 5px;
    width: 6px;
    height: 10px;
    border: solid white;
    border-width: 0 2px 2px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
</style>